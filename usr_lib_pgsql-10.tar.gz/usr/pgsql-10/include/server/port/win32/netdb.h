/* src/include/port/win32/netdb.h */
