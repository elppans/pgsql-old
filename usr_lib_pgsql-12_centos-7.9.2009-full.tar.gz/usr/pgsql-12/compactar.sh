#!/bin/bash

cd
tar -zcvf usr_lib_pgsql-12_centos-7.9.2009-full.tar.gz /usr/pgsql-12/ /lib/systemd/system/postgresql-12.service



