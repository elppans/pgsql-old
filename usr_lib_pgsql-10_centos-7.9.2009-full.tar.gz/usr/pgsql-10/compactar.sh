#!/bin/bash

cd
tar -zcvf usr_lib_pgsql-10_centos-7.9.2009-full.tar.gz /usr/pgsql-10/ /lib/systemd/system/postgresql-10.service


